export default {
    headerContainer:{
        backgroundColor: '#f1f1f1', 
        padding: '10px', 
        height: '50px'},
    menuItem:{
        cursor: 'pointer'
    },
    menuItemActive:{cursor: 'pointer', borderBottom: '2px solid red'}

}