import React, {Component} from 'react';
export default class UserDashboard extends Component{
render(){
    return <div>User dashboard works!</div>
}
}