import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import {getImg} from '../services'
import WithPartion from '../with-partion/with-partion.component'

class CoachPreview extends Component {
  constructor(props){
      super(props);  
      this.name = this.props.name;
      this.profile_pic = this.props.profile_pic;
      this.state={
      }
  }  
render() {
    let {name, profile_pic} = this.props;
        return (<Grid container direction="column" justify="center" alignItems="center">
            <div style={{width: '80%', margin: '0 auto', overflow: 'hidden'}}>
                <img style={{width: '100%'}} src = {getImg(profile_pic)}/>
            </div>
            <h3>{name}</h3>
        </Grid>)
    }
}
// export default WithPartion(CoachPreview);
export default CoachPreview;
