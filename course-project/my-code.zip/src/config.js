export default {
    baseUrl: 'https://api.getsetgo.fitness/base_ind/API/v1',
    apis:{
        coachList: 'searchtrainers/0',
        coachDetail: 'trainerdetails',
        signin:'sign-in'
    }
}
