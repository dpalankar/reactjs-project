import React, { Component } from 'react';

export default class UserDashBoard extends Component{
    constructor(props) {
        super(props);
    }
    render(){
        return (<div>User dash board works</div>);
    }
}

