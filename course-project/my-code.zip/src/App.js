import React, { Component } from 'react';
import './App.css';
import Grid from '@material-ui/core/Grid';
import Header from './header/Header.component';
import Home from './home/Home.component';
import Coaches from './coaches/Coaches.component';
import Sign from './sign/Signature.component';
import UserDashBoard from './user-dashboard/user-dashboard';
import {NavLink} from "react-router-dom";

import { BrowserRouter as Router,Route} from "react-router-dom";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeRoute: 2
    }
  }
  changeRoute(i) {
    this.setState({ activeRoute: i });
  }
  render() {
    // let test = this.state.activeRoute;
    // console.log(test);
    return (
      <Router>
        <div className="App">
          <Grid container direction="column">
            <Grid item style={{ padding:'5px', background: '#cec'}}>
              {/* <Header onRouteChange={this.changeRoute.bind(this)}></Header> */}
              <Header></Header>
              {/* <button onClick={() => { this.changeRoute(1)}}>Home</button>
              <button onClick={() => { this.changeRoute(2) }}>Coaches</button>
              <button onClick={() => { this.setState({ selectedRoute: 3 }) }}>SignIn</button> */}
            </Grid>
            {/* <Grid item>
              {
                this.state.activeRoute === 1 &&
                <Home></Home>
              }
              {
                this.state.activeRoute === 2 &&
                <Coaches></Coaches>
              }
              {
                this.state.selectedRoute === 3 &&
                <Signature></Signature>
              }
            </Grid> */}
            {/* <Route exact path='/home' render={()=><div>Home</div>}/> */}
            <Route exact path='/' component={Home}/>
            <Route path='/coaches/:id?' component={Coaches} ></Route>
            <Route path='/signin' component={Sign} >
            </Route>
            <Route path='/userdashboard' component={UserDashBoard}> </Route>
            {/* <Route path='/*' render={()=>
              <div style={{padding:'20px'}}> Uh Oh! you lost ?<br/>Go to home page &nbsp;&nbsp;
              <NavLink exact to='/' activeClassName="activeLink">Home</NavLink>
              </div>}>
            </Route> */}
          </Grid>
        </div>
        </Router>
    );
  }
}
export default App;
