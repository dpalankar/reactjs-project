import React, { Component } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import {callAPI, setStorage } from '../services'


class Sign extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            password: '',
            error_message : ''
        };
    }

    changeVal(e){   
        e.target.name == 'username'? this.setState({username:e.target.value}):this.setState({password:e.target.value});   
    }

    submitForm(){
        let data = {"user_email":this.state.username,"user_password":this.state.password,"user_type":"client"};
        callAPI('signin',(resp)=>{
           setStorage('auth',resp.data.token);
           this.props.history.push('userdashboard');
        },(error)=>{
            console.log('Error',error);
        },data,'post');
    }

    render() {
        let login = [{
            name: "username",
            type: "text",
            label: "Username",
        },{
            name: "password",
            type: "password",
            label: "Password",
        }
    ];

    // formsubmit(){

    // }

        return (
            <div style={{ padding: '20px' }}>
                <Paper variant="outlined" >
                {
                    login.map((ele)=>{
                        return <div>
                        <TextField id="standard-basic" 
                            value={ele.name==='username'?this.state.username:this.state.password}
                            type={ele.type} name={ele.name} label={ele.label}
                            onChange={(e)=>this.changeVal(e)}/>
                         <br/><br/>
                        </div>
                       
                    })
                }
                
                    {/* <TextField id="standard-basic" label="Username" value={this.state.username} name='username'
                    onChange={(e)=>this.changeVal(e)}/>
            <br/>
            <TextField id="standard-basic" label="Password" type="password" value={this.state.password} name='password'
                    onChange={(e)=>this.changeVal(e)}/>
            <br/>
            <br/>*/}
            <div style={{color:'red'}}>{this.state.error_message} </div>
            <br/>
            <Button variant="contained" color="primary" onClick={()=>this.submitForm()}>
                    Sign
            </Button> 
            <br/>
                </Paper>
            </div>
        );
    }
}
export default Sign;
