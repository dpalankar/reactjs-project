import React, { Component } from 'react';
import { Grid } from '@material-ui/core';
import { getHt,callAPI } from '../services';
// import CoachList from '../tempData';
import CoachPreview from '../coache-preview/CoachPreview.component';
import CoachDetail from '../coach-detail/coach-detail';
import { } from 'react-router-dom'

let docHt = getHt() - 50;
// let coachList= [];
const axios = require('axios').default;
class Coaches extends Component {
    constructor(props) {
        super(props);
        let selectCoach = this.props.match.params.id;
        this.state = { activeCoach: this.props.match.params.id || 0,coachList:[]}
    }

    redirectCoaches(indx) {
        this.props.history.push(`/coaches/${indx}`);
    }

    // shouldComponentUpdate(nextprops, currprops) {
    //     console.log('old', this.props.match.params.id)
    //     console.log('new', nextprops.match.params.id)

    //     if (this.state.activeCoach !== nextprops.match.params.id) {
    //         this.state.activeCoach = nextprops.match.params.id
    //         return true;
    //     }
    //     return false;
    // }

    componentDidMount(){
        // axios.get('https://api.getsetgo.fitness/base_ind/API/v1/searchtrainers/0')
        //     .then(response=> {
        //         let self = this;
        //         console.log(response.data.ConsultantList[0]);
        //         self.setState({coachList:response.data.ConsultantList[0]});
        //     })
        //     .catch(function (error) {
        //         console.log(error);
        //     });
        callAPI('coachList',(resp)=>{
            let self = this;
            self.setState({coachList:resp.data.ConsultantList[0]});
        },(error)=>{
            console.log(error);
        },
        this.props.name,'get');
    }

    renderDom(){
        
        let { activeCoach,coachList} = this.state;
        return (<div> {coachList.length > 0 && <Grid container direction='rows' style={{ height: docHt }}>
                <Grid item xs={3} style={{ backgroundColor: 'blue' }} >
                    {
                        coachList.map((coach, indx) => {
                            return (
                                <div onClick={() => { this.redirectCoaches(indx) }}>
                                    <CoachPreview name={coach.name} profile_pic={coach.profile_pic}></CoachPreview>
                                </div>
                            )
                        })}
                </Grid>
                <Grid item xs={9} style={{ backgroundColor: 'green' }}>
                    <CoachDetail name={coachList[activeCoach].name}></CoachDetail>
                </Grid>
            </Grid>
            }
            {coachList.length===0 && <div>Loading ...</div>

            }</div>)
    }

    render() {
        // let { activeCoach,coachList} = this.state;
        return (
            <div>
                {this.renderDom()}
            </div>
        );
    }
}
export default Coaches;
