export default {
    headerContainer: { backgroundColor: '#f1f1f1', padding: '10px', height: '50px' },
    menuitem: { cursor:'pointer'},
    menuitemActive: { cursor:'pointer',backgroundColor:'red'},
    selected: { backgroundColor:'red'}

}