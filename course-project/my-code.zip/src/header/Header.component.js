import React, { Component } from 'react';
import { Grid } from '@material-ui/core';
import Style from './Header.style'
import {NavLink} from "react-router-dom";

class Header extends Component {

   constructor(props){
        super(props);
        // this.state={
        //     activeRoute: 1
        // }
   }

render() {
    // console.log(this.props);
    
    // let {onRouteChange} = this.props;
    let {onRouteChange} = this.props;
    // console.log(this.props.state.activeRoute);
    // console.log(activeRoute);
    let activeRoute =1;
    
    return (
        <Grid container direction="row" justify="space-between" 
        style={Style.headerContainer}>
            <Grid item xs ={8}>
                <Grid container direction="row" justify="flex-start">
                    {/* <Grid item xs ={2}  onClick={()=>{onRouteChange(1)}} 
                        style={activeRoute ===1 ?Style.menuitemActive:Style.menuitem}>
                        Home
                    </Grid>
                    <Grid item xs ={2}  onClick={()=>{onRouteChange(2)}} 
                        style={activeRoute ===2 ?Style.menuitemActive:Style.menuitem}>
                        Coaches
                    </Grid> */}
                    <Grid item xs ={2} style={Style.menuitem} > 
                        <NavLink exact to='/' activeClassName="activeLink">Home</NavLink >
                    </Grid>
                    <Grid item xs ={2} style={Style.menuitem}>
                        <NavLink  to='/coaches' activeClassName="activeLink">Coaches</NavLink >
                    </Grid>                   
                </Grid>                
            </Grid>
            <Grid item xs ={4}><NavLink  to='/signin' activeClassName="activeLink">Sign</NavLink ></Grid>
        </Grid>
    );
    }
}
export default Header;
