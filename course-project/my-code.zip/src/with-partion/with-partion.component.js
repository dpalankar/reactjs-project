import React, { Component } from 'react';

function WithPartion(Component,props={name:'Malvin',profile_pic:'melvin.jpg'}) {
    return class extends Component {
        render(){
            return (
                <div>
                    <Component name={props.name} profile_pic={props.profile_pic}/>
                    <hr/>
                </div>
            )
        }
    }
}

export default WithPartion;

// class WithPartion extends Component {
// render(){
//         return (
//             <div>
//                 <this.props.children></this.props.children>                
//                 <hr/>
//             </div>
//         )
//     }
// }

// export default WithPartion;