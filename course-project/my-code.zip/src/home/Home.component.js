import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import { getHt } from '../services';
import Button from '@material-ui/core/Button';

let docHt = getHt() - 50;
class Home extends Component {
    render() {
        return (
            // <div style={{ height: docHt, background: '#ccc' }}>
            <Grid
                container
                direction="row"
                justify="flex-start"
                alignItems="center"
                style={{ height: docHt, background: '#ccc' }}
            >
                <Grid item style={{  marginLeft:'100px',textAlign:'left'}} xs={3}>
                   <h1>Keep it simple</h1>
                   <p>BKJbsabkja lknsafknasfc snfksanfl</p>
                   <div>
                   <Button variant="contained" color="primary">
                     Getting Started
                   </Button>
                   </div>
                </Grid>
                {/* <Grid item><div style={{ background: '#432', with: '50px' }}>Home Component 2</div></Grid>
                <Grid item><div style={{ background: '#932', with: '50px' }}>Home Component 3</div> </Grid> */}
            </Grid>
        );
    }
}
export default Home;
