import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import { getImg,callAPI } from '../services'
const axios = require('axios').default;

class CoachDetail extends Component {

    constructor(props) {
        super(props);
        this.state ={
            profile_pic : null 
        }
    }

    componentDidMount(){
        console.log('name ',this.props.name);
        callAPI('coachDetail',(resp)=>{
            let self = this;
            self.setState({profile_pic:resp.data.trainer_details[0].profile_pic});
        },(error)=>{
            console.log(error);
        },
        this.props.name,'get');
        // let { name } = this.props;
        // let self = this;
        // axios.get(`https://api.getsetgo.fitness/base_ind/API/v1/trainerdetails/${this.props.name}`)
        //     .then(response => {
        //         console.log(response.data.trainer_details[0]);
        //         self.setState({profile_pic:response.data.trainer_details[0].profile_pic});
        //     })
        //     .catch(function (error) {
        //         console.log(error);
        //     });
    }

    loadImage() {      
       let {name} = this.props;
       let {profile_pic} =this.state;
       console.log(this.state.profile_pic)
       console.log('profile_pic',profile_pic)
        return (<div>
            {profile_pic==undefined && <div>loading...</div>}
            {profile_pic!=undefined && <Grid container direction="column" justify="flex-start" alignItems="center" >
                <Grid item style={{ width: '100%' }}>
                    <div style={{ width: '60%', margin: '0 auto' }}>
                        <img style={{ width: '100%' }} src={getImg(profile_pic)} />
                    </div>
                </Grid>
                <Grid>
                    <h2>{name}</h2>
                </Grid>
                <Grid>
                    A FITMOM, who understand how to manage fitness between your daily chores
            </Grid>
            </Grid>
            }
           
        </div>)
    }

    render() {
        return (<div>
            {this.loadImage()}
        </div>)
    }
    // render(){
    //     let {name, profile_pic} = this.props;
    //     return (
    //         <Grid container direction="column" justify="flex-start" alignItems="center" >
    //             <Grid item style={{width: '100%'}}>
    //                 <div style={{width: '60%', margin: '0 auto'}}>
    //                     <img style={{width: '100%'}} src={getImg(profile_pic)}/>
    //                 </div>
    //             </Grid>
    //             <Grid>
    //                 <h2>{name}</h2>
    //             </Grid>
    //             <Grid>
    //             A FITMOM, who understand how to manage fitness between your daily chores
    //             </Grid>
    //         </Grid>
    //     )
    // }
}

export default CoachDetail;