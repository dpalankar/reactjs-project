import config from './config';
const axios = require('axios').default;
function getHt() {
    return document.documentElement.clientHeight;
}

function getImg(image) {
    return (`https://gsg-image-uploads.s3-accelerate.amazonaws.com/webcontent/img/coaches/profilePic/${image}`)
}

function fakeLogin() {

}

function returnURL(api) {
    return `${config.baseUrl}/${config.apis[api]}`
}

function callAPI(api, success, err, data, method) {
    console.log(returnURL(api)+''+data);
    if (method === 'get') {
        axios.get(`${returnURL(api)}${data ? '/' + data : ''}`)
            .then(response => {
                success(response);
            })
            .catch(function (error) {
                console.log(error);
            });
    }
    if (method === 'post') {
        axios.post(`${returnURL(api)}`, data)
            .then(function (response) {
                success(response);
            }).catch(function (error) {
                console.log(error);
            });
    }

}

function setStorage(name,value){
    localStorage.setItem(name,value);
}

function getStorage(name){    
    return localStorage.getItem(name);
}

export { getHt, getImg, fakeLogin,callAPI,setStorage,getStorage }